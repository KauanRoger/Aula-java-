package exercicios;
import java.util.Scanner;
public class Erxecicio12 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

       
        int somaPares = 0;
        int somaImpares = 0;

        System.out.println("Digite números inteiros (insira 999 para encerrar):");

       
        int numero;
        do {
            numero = scanner.nextInt();

            if (numero != 999) {
                
                if (numero % 2 == 0) {
                    somaPares += numero;
                } else {
                    somaImpares += numero;
                }
            }

        } while (numero != 999);

        
        System.out.println("Soma dos números pares: " + somaPares);
        System.out.println("Soma dos números ímpares: " + somaImpares);

        scanner.close();
    }
}


