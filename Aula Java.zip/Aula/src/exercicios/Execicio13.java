package exercicios;
import java.util.Arrays;
import java.util.Scanner;

public class Execicio13 {

public class OrdenarNomes {

    public static void main(String[] args) {
      
        Scanner scanner = new Scanner(System.in);

       
        String[] nomes = new String[5];

       
        for (int i = 0; i < 5; i++) {
            System.out.print("Digite o nome " + (i + 1) + ": ");
            nomes[i] = scanner.nextLine();
        }

       
        Arrays.sort(nomes);

       
        System.out.println("\nNomes em ordem alfabética:");
        for (String nome : nomes) {
            System.out.println(nome);
        }

       
        scanner.close();
    }
}


}
