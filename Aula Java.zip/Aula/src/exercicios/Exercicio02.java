package exercicios;

public class Exercicio02 {
    public static void main(String[]args) {
	      for (int i = 1; i <= 20; i++) {
	            System.out.println(i);
	            if (i%2 == 0) {
	            	System.out.println(i);
	            	
	            	}
	            }
	        }
	    }
	 