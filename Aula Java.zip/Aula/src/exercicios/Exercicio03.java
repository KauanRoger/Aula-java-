package exercicios;

public class Exercicio03 {
	public static void main(String[]args) {
		  int limiteSuperior = 50;
		  int soma = 0;
		    for (int i = 1; i <= limiteSuperior;i += 2) {
		    	 soma += i;
		    	  }
		    	 System.out.println("A soma dos números ímpares de 1 a "+ limiteSuperior + " é: " + soma);
		    	 
		    }

}
