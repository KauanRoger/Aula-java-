package exercicios;
import java.util.Scanner;

public class Exercicio04 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Digite cinco números:");

        int maiorNumero = Integer.MIN_VALUE;

        for (int i = 0; i < 5; i++) {
            System.out.print("Número " + (i + 1) + ": ");
            int numero = scanner.nextInt();

          
            if (numero > maiorNumero) {
                maiorNumero = numero;
            }
        }
        System.out.println("O maior número é: " + maiorNumero);

        scanner.close();
    }
}

