package exercicios;
import java.util.Scanner;
public class Exercicio06 {

 public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

      
        System.out.print("Digite o tamanho do array: ");
        int tamanhoArray = scanner.nextInt();

       
        int[] numeros = new int[tamanhoArray];

        
        for (int i = 0; i < tamanhoArray; i++) {
            System.out.print("Digite o número " + (i + 1) + ": ");
            numeros[i] = scanner.nextInt();
        }

       
        int soma = 0;
        for (int i = 0; i < tamanhoArray; i++) {
            soma += numeros[i];
        }

       
        System.out.println("A soma dos números é: " + soma);

       
        scanner.close();
    }
}
