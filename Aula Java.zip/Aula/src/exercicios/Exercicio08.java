package exercicios;
import java.util.Scanner;
public class Exercicio08 {
 
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

       
        int[] numeros = new int[100]; 
        int quantidadeNumeros = 0;

      
        while (true) {
            System.out.print("Digite um número (ou 0 para parar): ");
            int numero = scanner.nextInt();

          
            if (numero == 0) {
                break;
            }

           
            numeros[quantidadeNumeros] = numero;
            quantidadeNumeros++;
        }
    }
}

        
