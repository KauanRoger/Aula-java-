package exercicios;
import java.util.Scanner;
public class Exercicio09 {

public class ArrayLeituraAteRepeticao {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Digite os números (insira um número repetido para encerrar):");

       
        java.util.ArrayList<Integer> numeros = new java.util.ArrayList<>();

        while (true) {
            System.out.print("Número: ");
            int numero = scanner.nextInt();

            
            if (numeros.contains(numero)) {
                System.out.println("Número repetido detectado! Encerrando o programa.");
                break;
            }

            
            numeros.add(numero);
        }

       
        System.out.println("Quantidade de números lidos antes da repetição: " + numeros.size());

        scanner.close();
    }
}


}
