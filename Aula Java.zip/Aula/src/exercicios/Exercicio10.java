package exercicios;
import java.util.Scanner;
public class Exercicio10 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

      
        int menorNumero = Integer.MAX_VALUE;

       
        for (int i = 0; i < 10; i++) {
            System.out.print("Digite o número " + (i + 1) + ": ");
            int numero = scanner.nextInt();

         
            if (numero < menorNumero) {
                menorNumero = numero;
            }
        }

       
        System.out.println("O menor número é: " + menorNumero);

        
        scanner.close();
    }
}

