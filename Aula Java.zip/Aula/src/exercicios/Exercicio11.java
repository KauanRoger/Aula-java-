package exercicios;
import java.util.Scanner;
public class Exercicio11 {

public class MediaArray {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        
        java.util.ArrayList<Double> numeros = new java.util.ArrayList<>();

      
        System.out.println("Insira números (insira um número negativo para encerrar):");

        double numero;
        do {
            System.out.print("Digite um número: ");
            numero = scanner.nextDouble();

       
            if (numero >= 0) {
                numeros.add(numero);
            }

        } while (numero >= 0);

    
        double soma = 0;
        for (double num : numeros) {
            soma += num;
        }
        double media = numeros.isEmpty() ? 0 : soma / numeros.size();

  
        System.out.println("A média dos números inseridos é: " + media);

        scanner.close();
    }
}


}
