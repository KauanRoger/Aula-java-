package exercicios;
import java.util.Scanner;
public class Exercicio14 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Digite os números (insira um número maior que o anterior para encerrar):");

        
        int[] numeros = new int[100]; 

       
        int indice = 0;
        while (true) {
            System.out.print("Número " + (indice + 1) + ": ");
            int numero = scanner.nextInt();

           
            if (indice > 0 && numero > numeros[indice - 1]) {
                System.out.println("Você inseriu um número maior. Programa encerrado.");
                break;
            }

          
            numeros[indice] = numero;
            indice++;
        }

     
        System.out.println("Números inseridos:");
        for (int i = 0; i < indice; i++) {
            System.out.println(numeros[i]);
        }

       
        scanner.close();
    }
}



