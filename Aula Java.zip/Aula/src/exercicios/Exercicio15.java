package exercicios;
import java.util.Scanner;
public class Exercicio15 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Digite números e pressione Enter. O programa continuará até que você digite o primeiro número novamente.");

      
        int primeiroNumero = scanner.nextInt();
        int numeroAtual;

        do {
     
            numeroAtual = scanner.nextInt();

            
            if (numeroAtual != primeiroNumero) {
                System.out.println("Você digitou um número diferente. Continue digitando.");
            }

        } while (numeroAtual != primeiroNumero);

        System.out.println("Você digitou novamente o primeiro número. O programa encerrou.");
        scanner.close();
    }
}

