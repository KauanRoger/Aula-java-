package exercicios;
import java.util.Scanner;
public class Exercicio16 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Digite números para preencher o array. Insira um número primo para encerrar.");

       
        int[] numeros = new int[100]; 

        int indice = 0;
        boolean encontrouPrimo = false;

        while (!encontrouPrimo) {
            System.out.print("Digite um número: ");
            int numero = scanner.nextInt();

            // Adicione o número ao array
            numeros[indice] = numero;
            indice++;

           
            if (ehPrimo(numero)) {
                encontrouPrimo = true;
            }
        }

        System.out.println("Número primo encontrado! O programa será encerrado.");

        
        System.out.println("Números inseridos:");
        for (int i = 0; i < indice; i++) {
            System.out.print(numeros[i] + " ");
        }

       
        scanner.close();
    }

    
    private static boolean ehPrimo(int numero) {
        if (numero <= 1) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(numero); i++) {
            if (numero % i == 0) {
                return false;
            }
        }
        return true;
    }
}

