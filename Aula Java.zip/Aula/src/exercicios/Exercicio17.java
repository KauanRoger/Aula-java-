package exercicios;
import java.util.Scanner;
public class Exercicio17 {


    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Digite os números (digite um número que seja a soma dos dois anteriores para encerrar):");

    
        int[] numeros = new int[3];
        numeros[0] = scanner.nextInt();
        numeros[1] = scanner.nextInt();

    
        int index = 2;
        while (true) {
            int soma = numeros[index - 1] + numeros[index - 2];
            System.out.println("Digite um número (soma dos dois anteriores):");
            int numero = scanner.nextInt();

            if (numero == soma) {
                System.out.println("Você acertou! O número inserido é a soma dos dois anteriores. Encerrando o programa.");
                break;
            } else {
                numeros = aumentarArray(numeros, numero);
                index++;
            }
        }

        scanner.close();
    }

  
    private static int[] aumentarArray(int[] arrayAntigo, int novoNumero) {
        int[] novoArray = new int[arrayAntigo.length + 1];
        System.arraycopy(arrayAntigo, 0, novoArray, 0, arrayAntigo.length);
        novoArray[arrayAntigo.length] = novoNumero;
        return novoArray;
    }
}



