package exercicios;
import java.util.Scanner;
public class Exercicio19 {



    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        
        System.out.print("Digite o tamanho do array: ");
        int tamanho = scanner.nextInt();

       
        int[] numeros = new int[tamanho];

       
        for (int i = 0; i < tamanho; i++) {
            System.out.print("Digite o elemento " + (i + 1) + ": ");
            numeros[i] = scanner.nextInt();
        }

       
        int menorNumero = numeros[0];
        int posicaoMenorNumero = 0;

        for (int i = 1; i < tamanho; i++) {
            if (numeros[i] < menorNumero) {
                menorNumero = numeros[i];
                posicaoMenorNumero = i;
            }
        }

        
        System.out.println("Menor número: " + menorNumero);
        System.out.println("Posição no array: " + posicaoMenorNumero);

        scanner.close();
    }
}



