package exercicios;
import java.util.Scanner;
public class Exercicio20 {

    public static void main(String[] args) {
       
        Scanner scanner = new Scanner(System.in);

        
        System.out.print("Digite o tamanho do array: ");
        int tamanho = scanner.nextInt();

        
        int[] numeros = new int[tamanho];

        
        System.out.println("Digite os números do array:");
        for (int i = 0; i < tamanho; i++) {
            System.out.print("Número " + (i + 1) + ": ");
            numeros[i] = scanner.nextInt();
        }

      
        double media = calcularMedia(numeros);

       
        int acimaDaMedia = contarAcimaDaMedia(numeros, media);

       
        System.out.println("A média dos números é: " + media);
        System.out.println("Quantidade de números acima da média: " + acimaDaMedia);

        
        scanner.close();
    }

   
    private static double calcularMedia(int[] numeros) {
        int soma = 0;
        for (int num : numeros) {
            soma += num;
        }
        return (double) soma / numeros.length;
    }


    private static int contarAcimaDaMedia(int[] numeros, double media) {
        int contador = 0;
        for (int num : numeros) {
            if (num > media) {
                contador++;
            }
        }
        return contador;
    }
}



