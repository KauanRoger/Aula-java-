package exercicios;
import java.util.Scanner;
public class Exercicio22 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

     
        java.util.List<String> nomes = new java.util.ArrayList<>();

        
        System.out.println("Digite os nomes (digite 'FIM' para encerrar):");
        String nome = scanner.nextLine();
        while (!nome.equalsIgnoreCase("FIM")) {
            nomes.add(nome);
            nome = scanner.nextLine();
        }

        
        System.out.println("Nomes em ordem inversa:");
        for (int i = nomes.size() - 1; i >= 0; i--) {
            System.out.println(nomes.get(i));
        }

        scanner.close();
    }
}
