package exercicios;
import java.util.Scanner;
public class Exercicio23 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        
        int soma = 0;
        int quantidadeNumeros = 0;
        int quantidadePares = 0;

        System.out.println("Digite os números (insira um número negativo para parar):");

        
        while (true) {
            int numero = scanner.nextInt();

          
            if (numero < 0) {
                break;
            }

           
            soma += numero;
            quantidadeNumeros++;

           
            if (numero % 2 == 0) {
                quantidadePares++;
            }
        }

        
        if (quantidadeNumeros > 0) {
            double media = (double) soma / quantidadeNumeros;

            System.out.println("Média dos números lidos: " + media);
            System.out.println("Quantidade de números pares: " + quantidadePares);
        } else {
            System.out.println("Nenhum número foi inserido.");
        }

        
        scanner.close();
    }
}



