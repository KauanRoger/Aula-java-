package exercicios;
import java.util.Scanner;
public class Exercicio24 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        
        java.util.List<Double> numeros = new java.util.ArrayList<>();

        double soma = 0.0;
        double media = 0.0;

        while (true) {
            System.out.print("Insira um número (ou a média para sair): ");
            String input = scanner.nextLine();

            if (input.equalsIgnoreCase("média")) {
                if (numeros.isEmpty()) {
                    System.out.println("Nenhum número foi inserido ainda. Tente novamente.");
                    continue;
                }

                media = soma / numeros.size();
                break;
            }

            try {
                double numero = Double.parseDouble(input);
                numeros.add(numero);
                soma += numero;
            } catch (NumberFormatException e) {
                System.out.println("Por favor, insira um número válido.");
            }
        }

        System.out.println("Números inseridos: " + numeros);
        System.out.println("Média calculada: " + media);

        scanner.close();
    }
}



