package exercicios;
import java.util.Scanner;
public class Exercicio27 {

    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);

       
        System.out.print("Informe o saldo: ");
        
       
        double saldo = scanner.nextDouble();

     
        double reajuste = saldo * 0.01;

     
        double novoSaldo = saldo + reajuste;


        System.out.println("Saldo com reajuste de 1%: " + novoSaldo);

       
        scanner.close();
    }
}



