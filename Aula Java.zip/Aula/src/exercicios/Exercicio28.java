package exercicios;
import java.util.Scanner;
public class Exercicio28 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

      
        System.out.print("Informe a porcentagem do IPI a ser acrescido: ");
        double ipiPorcentagem = scanner.nextDouble();

    
        System.out.println("\nDigite os dados da peça 1:");
        int codigoPeca1 = lerCodigoPeca(scanner);
        double valorUnitarioPeca1 = lerValorUnitario(scanner);
        int quantidadePeca1 = lerQuantidade(scanner);

      
        System.out.println("\nDigite os dados da peça 2:");
        int codigoPeca2 = lerCodigoPeca(scanner);
        double valorUnitarioPeca2 = lerValorUnitario(scanner);
        int quantidadePeca2 = lerQuantidade(scanner);

      
        double totalPeca1 = calcularTotal(valorUnitarioPeca1, quantidadePeca1, ipiPorcentagem);
        double totalPeca2 = calcularTotal(valorUnitarioPeca2, quantidadePeca2, ipiPorcentagem);
        double totalCompra = totalPeca1 + totalPeca2;

      
        System.out.println("\nResumo da compra:");
        exibirResumo(codigoPeca1, valorUnitarioPeca1, quantidadePeca1, totalPeca1);
        exibirResumo(codigoPeca2, valorUnitarioPeca2, quantidadePeca2, totalPeca2);

        System.out.printf("\nValor total da compra: R$%.2f%n", totalCompra);

   
        scanner.close();
    }

    private static int lerCodigoPeca(Scanner scanner) {
        System.out.print("Código da peça: ");
        return scanner.nextInt();
    }

    private static double lerValorUnitario(Scanner scanner) {
        System.out.print("Valor unitário da peça: R$");
        return scanner.nextDouble();
    }

    private static int lerQuantidade(Scanner scanner) {
        System.out.print("Quantidade de peças: ");
        return scanner.nextInt();
    }

    private static double calcularTotal(double valorUnitario, int quantidade, double ipiPorcentagem) {
        double totalSemIPI = valorUnitario * quantidade;
        double ipi = totalSemIPI * (ipiPorcentagem / 100);
        return totalSemIPI + ipi;
    }

    private static void exibirResumo(int codigoPeca, double valorUnitario, int quantidade, double total) {
        System.out.printf("\nCódigo da peça: %d%n", codigoPeca);
        System.out.printf("Valor unitário: R$%.2f%n", valorUnitario);
        System.out.printf("Quantidade: %d%n", quantidade);
        System.out.printf("Total com IPI: R$%.2f%n", total);
    }
}


