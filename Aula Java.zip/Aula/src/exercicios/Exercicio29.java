package exercicios;
import java.util.Scanner;
public class Exercicio29 {

    public static void main(String[] args) {
     
        double salarioMinimo = 1500.0;

        
        double salarioUsuario = obterSalarioUsuario();

        
        double quantidadeSalariosMinimos = calcularQuantidadeSalariosMinimos(salarioUsuario, salarioMinimo);

      
        System.out.println("O usuário ganha " + quantidadeSalariosMinimos + " salários mínimos.");
    }

  
    private static double obterSalarioUsuario() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite o valor do salário do usuário: ");
        return scanner.nextDouble();
    }

    
    private static double calcularQuantidadeSalariosMinimos(double salarioUsuario, double salarioMinimo) {
        return salarioUsuario / salarioMinimo;
    }
}



