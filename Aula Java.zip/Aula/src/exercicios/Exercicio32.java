package exercicios;
import java.util.Scanner;
public class Exercicio32 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        
        System.out.print("Informe o valor total da compra: ");
        double valorTotal = scanner.nextDouble();

        
        System.out.print("Informe o valor pago: ");
        double valorPago = scanner.nextDouble();

        
        double troco = calcularTroco(valorTotal, valorPago);

        
        System.out.println("Troco a ser dado: " + troco);

        scanner.close();
    }

   
    private static double calcularTroco(double valorTotal, double valorPago) {
        if (valorPago < valorTotal) {
            System.out.println("Valor pago insuficiente.");
            return 0; 
        }

        return valorPago - valorTotal;
    }
}



