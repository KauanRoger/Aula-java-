package exercicios;
import java.util.Scanner;
public class Exercicio33 {

    public static void main(String[] args) {
   
        Scanner scanner = new Scanner(System.in);
        System.out.print("Informe o valor total da nota fiscal: ");
        double valorNotaFiscal = scanner.nextDouble();

      
        double valorIva = calcularIVA(valorNotaFiscal);
        double valorIcms = calcularICMS(valorNotaFiscal);

        System.out.println("\nResumo da Nota Fiscal:");
        System.out.println("Valor Total da Nota Fiscal: R$ " + valorNotaFiscal);
        System.out.println("Valor do IVA: R$ " + valorIva);
        System.out.println("Valor do ICMS: R$ " + valorIcms);
    }

   
    private static double calcularIVA(double valorNotaFiscal) {
        double taxaIva = 0.10; // 10%
        return valorNotaFiscal * taxaIva;
    }


    private static double calcularICMS(double valorNotaFiscal) {
        double taxaIcms = 0.08; // 8%
        return valorNotaFiscal * taxaIcms;
    }
}



