package exercicios;
import java.util.Scanner;
public class Exercicio35 {


    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Digite o primeiro número binário: ");
        String binario1 = scanner.nextLine();

        System.out.println("Digite o segundo número binário: ");
        String binario2 = scanner.nextLine();

        String resultado = somarBinarios(binario1, binario2);

        System.out.println("A soma dos números binários é: " + resultado);
    }

 
    private static String somarBinarios(String bin1, String bin2) {
        int tamanhoMaximo = Math.max(bin1.length(), bin2.length());

  
        bin1 = completarZerosEsquerda(bin1, tamanhoMaximo);
        bin2 = completarZerosEsquerda(bin2, tamanhoMaximo);

        StringBuilder resultado = new StringBuilder();
        int carry = 0;

     
        for (int i = tamanhoMaximo - 1; i >= 0; i--) {
            int bit1 = bin1.charAt(i) - '0';
            int bit2 = bin2.charAt(i) - '0';

    
            int soma = bit1 + bit2 + carry;
            resultado.insert(0, soma % 2);

          
            carry = soma / 2;
        }

      
        if (carry > 0) {
            resultado.insert(0, carry);
        }

        return resultado.toString();
    }

    
    private static String completarZerosEsquerda(String binario, int tamanhoAlvo) {
        StringBuilder resultado = new StringBuilder(binario);
        while (resultado.length() < tamanhoAlvo) {
            resultado.insert(0, '0');
        }
        return resultado.toString();
    }
}


	
