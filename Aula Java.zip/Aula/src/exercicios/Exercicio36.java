package exercicios;
import java.util.Scanner;
public class Exercicio36 {


    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o primeiro número binário: ");
        String binario1 = scanner.nextLine();

        System.out.print("Digite o segundo número binário: ");
        String binario2 = scanner.nextLine();

        String resultado = multiplicarBinarios(binario1, binario2);

        System.out.println("Resultado da multiplicação: " + resultado);
    }

   
    private static String multiplicarBinarios(String binario1, String binario2) {
        int tamanho1 = binario1.length();
        int tamanho2 = binario2.length();
        int[] resultadoInt = new int[tamanho1 + tamanho2];

        
        binario1 = new StringBuilder(binario1).reverse().toString();
        binario2 = new StringBuilder(binario2).reverse().toString();

      
        for (int i = 0; i < tamanho1; i++) {
            for (int j = 0; j < tamanho2; j++) {
                resultadoInt[i + j] += (binario1.charAt(i) - '0') * (binario2.charAt(j) - '0');
            }
        }

      
        StringBuilder resultadoBinario = new StringBuilder();
        for (int i = 0; i < resultadoInt.length; i++) {
            int soma = resultadoInt[i] % 2;
            int carry = resultadoInt[i] / 2;
            resultadoBinario.insert(0, soma);
            if (i < resultadoInt.length - 1) {
                resultadoInt[i + 1] += carry;
            }
        }

        while (resultadoBinario.length() > 1 && resultadoBinario.charAt(0) == '0') {
            resultadoBinario.deleteCharAt(0);
        }

        return resultadoBinario.toString();
    }
}



